# BizSim Prototype

A web-based interactive business simulation app for students and lecturers.

## Setup

```bash
npm install
npm run dev
```

## Deployment
Use Vercel, Netlify, or any static web hosting supporting Next.js apps.
