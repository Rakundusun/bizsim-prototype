import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import Image from "next/image";

export default function BizSimApp() {
  const [loggedInRole, setLoggedInRole] = React.useState(null);

  const handleLogin = (role) => {
    setLoggedInRole(role);
  };

  if (loggedInRole === "pelajar") {
    return (
      <div className="min-h-screen bg-gray-100 flex flex-col items-center p-4">
        <Card className="w-full max-w-4xl">
          <CardContent className="p-6">
            <div className="flex items-center gap-4 mb-4">
              <Image src="/SampleLogo.png" alt="Sample Logo" width={50} height={50} />
              <h2 className="text-xl font-bold">Selamat Datang, Pelajar!</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-2">Status Kedai</h3>
                  <p>Belum Cipta Kedai</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-2">Notifikasi Pensyarah</h3>
                  <p>Tiada notifikasi buat masa ini.</p>
                </CardContent>
              </Card>
            </div>
            <div className="mt-6 flex flex-col md:flex-row gap-4">
              <Button className="w-full md:w-auto">Cipta Kedai Maya</Button>
              <Button className="w-full md:w-auto" variant="outline">Lihat Prestasi</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loggedInRole === "pensyarah") {
    return (
      <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
        <Card className="w-full max-w-2xl">
          <CardContent className="p-6">
            <div className="flex items-center gap-4 mb-4">
              <Image src="/SampleLogo.png" alt="Sample Logo" width={50} height={50} />
              <h2 className="text-xl font-bold">Selamat Datang, Pensyarah!</h2>
            </div>
            <p>Skrin pensyarah akan dibangunkan dalam fasa seterusnya.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardContent className="p-6">
          <div className="flex flex-col items-center mb-4">
            <Image src="/SampleLogo.png" alt="Sample Logo" width={60} height={60} />
            <h1 className="text-2xl font-bold mt-2">BizSim</h1>
          </div>
          <Tabs defaultValue="pelajar">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="pelajar">Log Masuk Pelajar</TabsTrigger>
              <TabsTrigger value="pensyarah">Log Masuk Pensyarah</TabsTrigger>
            </TabsList>

            <TabsContent value="pelajar">
              <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); handleLogin("pelajar"); }}>
                <div>
                  <Label htmlFor="emailPelajar">Email Pelajar</Label>
                  <Input id="emailPelajar" type="email" placeholder="nama@institusi.edu" required />
                </div>
                <div>
                  <Label htmlFor="passwordPelajar">Kata Laluan</Label>
                  <Input id="passwordPelajar" type="password" required />
                </div>
                <Button className="w-full mt-4" type="submit">Log Masuk</Button>
              </form>
            </TabsContent>

            <TabsContent value="pensyarah">
              <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); handleLogin("pensyarah"); }}>
                <div>
                  <Label htmlFor="emailPensyarah">Email Pensyarah</Label>
                  <Input id="emailPensyarah" type="email" placeholder="nama@institusi.edu" required />
                </div>
                <div>
                  <Label htmlFor="passwordPensyarah">Kata Laluan</Label>
                  <Input id="passwordPensyarah" type="password" required />
                </div>
                <Button className="w-full mt-4" type="submit">Log Masuk</Button>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
